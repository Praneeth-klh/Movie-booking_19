package com.example.movie_booking.Service;
import com.example.movie_booking.dao.*;
import com.example.movie_booking.dto.ShowRequest;
import com.example.movie_booking.dto.ShowResponse;
import com.example.movie_booking.Exception.AppException;
import com.example.movie_booking.Model.*;
import lombok.RequiredArgsConstructor;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Service;

import java.time.LocalDate;
import java.util.List;

@Service
@RequiredArgsConstructor
public class ShowService {

    private final ShowDao    showDao;
    private final MovieDao   movieDao;
    private final ScreenDao  screenDao;
    private final TheaterDao theaterDao;

    public List<ShowResponse> getShowsByMovieAndDate(Long movieId, LocalDate date) {
        return showDao.findByMovieAndDate(movieId, date)
                .stream().map(this::toResponse).toList();
    }

    public ShowResponse getShowById(Long showId) {
        Show show = showDao.findById(showId)
                .orElseThrow(() -> new AppException("Show not found", HttpStatus.NOT_FOUND));
        return toResponse(show);
    }

    public Long addShow(ShowRequest req, Long managerId) {
        // Verify manager owns the screen's theater
        verifyManagerOwnsScreen(req.getScreenId(), managerId);

        // Check time conflict on same screen
        if (showDao.hasConflict(req.getScreenId(), req.getShowDate(), req.getShowTime(), null)) {
            throw new AppException(
                    "A show already exists on this screen at the given date and time",
                    HttpStatus.CONFLICT);
        }

        Show show = new Show(null,
                req.getMovieId(), req.getScreenId(),
                req.getShowDate(), req.getShowTime(),
                req.getPriceSilver(), req.getPriceGold(),
                req.getPricePlatinum(), true);

        return showDao.save(show);
    }

    public void cancelShow(Long showId, Long managerId) {
        Show show = showDao.findById(showId)
                .orElseThrow(() -> new AppException("Show not found", HttpStatus.NOT_FOUND));

        verifyManagerOwnsScreen(show.getScreenId(), managerId);
        showDao.softDelete(showId);
    }

    // ── Ownership guard ───────────────────────────────────────────
    private void verifyManagerOwnsScreen(Long screenId, Long managerId) {
        Screen screen = screenDao.findById(screenId)
                .orElseThrow(() -> new AppException("Screen not found", HttpStatus.NOT_FOUND));

        Theater theater = theaterDao.findById(screen.getHallId())
                .orElseThrow(() -> new AppException("Theater not found", HttpStatus.NOT_FOUND));

        if (!theater.getManagedBy().equals(managerId)) {
            throw new AppException("You do not manage this screen's theater", HttpStatus.FORBIDDEN);
        }
    }

    // ── Mapper ────────────────────────────────────────────────────
    private ShowResponse toResponse(Show s) {
        Movie  movie  = movieDao.findById(s.getMovieId()).orElse(null);
        Screen screen = screenDao.findById(s.getScreenId()).orElse(null);
        Theater theater = screen != null
                ? theaterDao.findById(screen.getHallId()).orElse(null) : null;

        int booked    = showDao.countBookedSeats(s.getShowId());
        int capacity  = screen != null ? screen.getSeatingCapacity() : 0;
        // Only 50% seats available online (as per rule)
        int available = Math.max(0, (capacity / 2) - booked);

        return new ShowResponse(
                s.getShowId(),
                s.getMovieId(),  movie  != null ? movie.getTitle()       : "N/A",
                s.getScreenId(), screen != null ? screen.getScreenName() : "N/A",
                theater!= null ? theater.getName()       : "N/A",
                theater!= null ? theater.getCity()       : "N/A",
                s.getShowDate(), s.getShowTime(),
                s.getPriceSilver(), s.getPriceGold(), s.getPricePlatinum(),
                available
        );
    }
}
