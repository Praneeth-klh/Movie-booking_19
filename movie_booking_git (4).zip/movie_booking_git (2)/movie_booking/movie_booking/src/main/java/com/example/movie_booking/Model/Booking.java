package com.example.movie_booking.Model;

import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.AllArgsConstructor;

import java.math.BigDecimal;
import java.time.LocalDateTime;

@Data
@NoArgsConstructor
@AllArgsConstructor
public class Booking {
    private Long bookingId;
    private Long userId;
    private Long showId;
    private BigDecimal totalAmount;
    private BigDecimal deliveryCharge;
    private String status;
    private String paymentMode;
    private String paymentRef;
    private LocalDateTime bookingTime;
}
