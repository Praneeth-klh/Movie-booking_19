package com.example.movie_booking.Controller;
import jakarta.validation.Valid;
import lombok.RequiredArgsConstructor;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.*;
import jakarta.servlet.http.HttpServletRequest;
import java.util.List;
import java.util.Map;
import com.example.movie_booking.dto.MovieRequest;
import com.example.movie_booking.Model.Movie;
import com.example.movie_booking.Service.MovieService;
@RestController
@RequestMapping("/api/movies")
@RequiredArgsConstructor
public class MovieController {

    private final MovieService movieService;

    // ── Public endpoints ─────────────────────────────────────────

    @GetMapping
    public ResponseEntity<List<Movie>> getAllMovies() {
        return ResponseEntity.ok(movieService.getAllMovies());
    }

    @GetMapping("/{id}")
    public ResponseEntity<Movie> getMovieById(@PathVariable Long id) {
        return ResponseEntity.ok(movieService.getMovieById(id));
    }

    @GetMapping("/search")
    public ResponseEntity<List<Movie>> search(@RequestParam String keyword) {
        return ResponseEntity.ok(movieService.searchMovies(keyword));
    }

    // ── Manager only endpoints ───────────────────────────────────

    @PostMapping
    public ResponseEntity<Map<String, String>> addMovie(
            @Valid @RequestBody MovieRequest request,
            HttpServletRequest httpRequest) {

        Long managerId = (Long) httpRequest.getAttribute("userId");
        movieService.addMovie(request, managerId);
        return ResponseEntity.ok(Map.of("message", "Movie added successfully"));
    }

    @PutMapping("/{id}")
    public ResponseEntity<Map<String, String>> updateMovie(
            @PathVariable Long id,
            @Valid @RequestBody MovieRequest request,
            HttpServletRequest httpRequest) {

        Long managerId = (Long) httpRequest.getAttribute("userId");
        movieService.updateMovie(id, request, managerId);
        return ResponseEntity.ok(Map.of("message", "Movie updated successfully"));
    }

    @DeleteMapping("/{id}")
    public ResponseEntity<Map<String, String>> deleteMovie(
            @PathVariable Long id,
            HttpServletRequest httpRequest) {

        Long managerId = (Long) httpRequest.getAttribute("userId");
        movieService.deleteMovie(id, managerId);
        return ResponseEntity.ok(Map.of("message", "Movie removed successfully"));
    }
}