package com.example.movie_booking.Service;
import com.example.movie_booking.dao.ScreenDao;
import com.example.movie_booking.dao.TheaterDao;
import com.example.movie_booking.dto.ScreenRequest;
import com.example.movie_booking.dto.ScreenResponse;
import com.example.movie_booking.Exception.AppException;
import com.example.movie_booking.Model.Screen;
import com.example.movie_booking.Model.Theater;
import lombok.RequiredArgsConstructor;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
@RequiredArgsConstructor
public class ScreenService {

    private final ScreenDao screenDao;
    private final TheaterDao theaterDao;

    // ── Public ───────────────────────────────────────────────────
    public List<ScreenResponse> getScreensByHall(Long hallId) {
        return screenDao.findByHallId(hallId)
                .stream()
                .map(s -> new ScreenResponse(
                        s.getScreenId(), s.getScreenName(),
                        s.getSeatingCapacity(), s.getScreenType()))
                .toList();
    }

    // ── Manager only ─────────────────────────────────────────────
    public Long addScreen(Long hallId, ScreenRequest req, Long managerId) {
        // Verify manager owns this theater
        verifyOwnership(hallId, managerId);

        Screen screen = new Screen(
                null, hallId,
                req.getScreenName(), req.getSeatingCapacity(),
                req.getScreenType(), true
        );
        return screenDao.save(screen);
    }

    public void updateScreen(Long hallId, Long screenId, ScreenRequest req, Long managerId) {
        verifyOwnership(hallId, managerId);

        screenDao.findById(screenId)
                .orElseThrow(() -> new AppException("Screen not found", HttpStatus.NOT_FOUND));

        Screen screen = new Screen(
                screenId, hallId,
                req.getScreenName(), req.getSeatingCapacity(),
                req.getScreenType(), true
        );
        int rows = screenDao.update(screen);
        if (rows == 0) {
            throw new AppException("Screen does not belong to this theater", HttpStatus.FORBIDDEN);
        }
    }

    public void deleteScreen(Long hallId, Long screenId, Long managerId) {
        verifyOwnership(hallId, managerId);

        screenDao.findById(screenId)
                .orElseThrow(() -> new AppException("Screen not found", HttpStatus.NOT_FOUND));

        int rows = screenDao.softDelete(screenId, hallId);
        if (rows == 0) {
            throw new AppException("Screen does not belong to this theater", HttpStatus.FORBIDDEN);
        }
    }

    // ── Ownership guard ───────────────────────────────────────────
    private void verifyOwnership(Long hallId, Long managerId) {
        Theater theater = theaterDao.findById(hallId)
                .orElseThrow(() -> new AppException("Theater not found", HttpStatus.NOT_FOUND));

        if (!theater.getManagedBy().equals(managerId)) {
            throw new AppException("You do not manage this theater", HttpStatus.FORBIDDEN);
        }
    }
}
