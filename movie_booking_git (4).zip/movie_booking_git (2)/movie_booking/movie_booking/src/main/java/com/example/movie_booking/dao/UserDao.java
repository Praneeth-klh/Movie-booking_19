package com.example.movie_booking.dao;
import com.example.movie_booking.Model.User;
import lombok.RequiredArgsConstructor;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.RowMapper;
import org.springframework.stereotype.Repository;

import java.util.Optional;

@Repository
@RequiredArgsConstructor

public class UserDao {

        private final JdbcTemplate jdbcTemplate;

        private final RowMapper<User> userRowMapper = (rs, rowNum) -> new User(
                rs.getLong("user_id"),
                rs.getString("name"),
                rs.getString("email"),
                rs.getString("password"),
                rs.getString("role")
        );

        public Optional<User> findByEmail(String email) {
            String sql = "SELECT * FROM users WHERE email = ?";
            return jdbcTemplate.query(sql, userRowMapper, email)
                    .stream().findFirst();
        }

        public boolean existsByEmail(String email) {
            String sql = "SELECT COUNT(*) FROM users WHERE email = ?";
            Integer count = jdbcTemplate.queryForObject(sql, Integer.class, email);
            return count != null && count > 0;
        }

        public Optional<User> findById(Long userId) {
            String sql = "SELECT * FROM users WHERE user_id = ?";
            return jdbcTemplate.query(sql, userRowMapper, userId)
                    .stream().findFirst();
        }

        public void save(User user) {
            String sql = "INSERT INTO users (name, email, password, role) VALUES (?, ?, ?, ?)";
            jdbcTemplate.update(sql, user.getName(), user.getEmail(),
                    user.getPassword(), user.getRole());
        }
}
