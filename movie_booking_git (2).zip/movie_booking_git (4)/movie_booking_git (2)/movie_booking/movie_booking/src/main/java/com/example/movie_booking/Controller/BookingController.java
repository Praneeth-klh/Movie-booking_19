package com.example.movie_booking.Controller;



import com.example.movie_booking.dto.BookingRequest;
import com.example.movie_booking.dto.BookingResponse;
import com.example.movie_booking.Service.BookingService;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.validation.Valid;
import lombok.RequiredArgsConstructor;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.Map;

@RestController
@RequestMapping("/api/bookings")
public class BookingController {

    @Autowired
    private BookingService bookingService;

    @PostMapping
    public ResponseEntity<?> createBooking(
            @Valid @RequestBody BookingRequest request,
            HttpServletRequest req) {

        Long userId = (Long) req.getAttribute("userId");
        if (userId == null) return ResponseEntity
                .status(HttpStatus.UNAUTHORIZED)
                .body(Map.of("error", "Invalid token"));

        BookingResponse response = bookingService.createBooking(request, userId);
        return ResponseEntity.ok(response);
    }

    @GetMapping
    public ResponseEntity<?> getMyBookings(HttpServletRequest req) {

        Long userId = (Long) req.getAttribute("userId");
        if (userId == null) return ResponseEntity
                .status(HttpStatus.UNAUTHORIZED)
                .body(Map.of("error", "Invalid token"));

        return ResponseEntity.ok(bookingService.getMyBookings(userId));
    }

    @GetMapping("/{bookingId}")
    public ResponseEntity<?> getBookingById(
            @PathVariable Long bookingId,
            HttpServletRequest req) {

        Long userId = (Long) req.getAttribute("userId");
        if (userId == null) return ResponseEntity
                .status(HttpStatus.UNAUTHORIZED)
                .body(Map.of("error", "Invalid token"));

        return ResponseEntity.ok(bookingService.getBookingById(bookingId, userId));
    }

    @PatchMapping("/{bookingId}/cancel")
    public ResponseEntity<?> cancelBooking(
            @PathVariable Long bookingId,
            HttpServletRequest req) {

        Long userId = (Long) req.getAttribute("userId");
        if (userId == null) return ResponseEntity
                .status(HttpStatus.UNAUTHORIZED)
                .body(Map.of("error", "Invalid token"));

        bookingService.cancelBooking(bookingId, userId);
        return ResponseEntity.ok(Map.of("message", "Booking cancelled successfully"));
    }
}