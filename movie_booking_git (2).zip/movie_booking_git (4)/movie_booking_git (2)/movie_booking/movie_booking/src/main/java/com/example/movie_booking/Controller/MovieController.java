package com.example.movie_booking.Controller;
import jakarta.validation.Valid;
import lombok.RequiredArgsConstructor;

import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.*;
import jakarta.servlet.http.HttpServletRequest;
import java.util.List;
import java.util.Map;
import com.example.movie_booking.dto.MovieRequest;
import com.example.movie_booking.Model.Movie;
import com.example.movie_booking.Service.MovieService;
@RestController
@RequestMapping("/api/movies")
@RequiredArgsConstructor
public class MovieController {

    private final MovieService movieService;

    // ── Public endpoints ─────────────────────────────────────────

    @GetMapping
    public ResponseEntity<List<Movie>> getAllMovies() {
        return ResponseEntity.ok(movieService.getAllMovies());
    }

    @GetMapping("/{id}")
    public ResponseEntity<Movie> getMovieById(@PathVariable Long id) {
        return ResponseEntity.ok(movieService.getMovieById(id));
    }

    @GetMapping("/search")
    public ResponseEntity<List<Movie>> search(@RequestParam String keyword) {
        return ResponseEntity.ok(movieService.searchMovies(keyword));
    }

    // ── Manager only endpoints ───────────────────────────────────
    @PreAuthorize("hasRole('MANAGER')")
@PostMapping
public ResponseEntity<?> addMovie(
        @Valid @RequestBody MovieRequest request,
        HttpServletRequest req) {

    Long managerId = (Long) req.getAttribute("userId");
    if (managerId == null) return ResponseEntity
            .status(HttpStatus.UNAUTHORIZED)
            .body(Map.of("error", "Invalid token"));

    movieService.addMovie(request, managerId);
    return ResponseEntity.ok(Map.of("message", "Movie added successfully"));
}

@PreAuthorize("hasRole('MANAGER')")
@PutMapping("/{id}")
public ResponseEntity<?> updateMovie(
        @PathVariable Long id,
        @Valid @RequestBody MovieRequest request,
        HttpServletRequest req) {

    Long managerId = (Long) req.getAttribute("userId");
    if (managerId == null) return ResponseEntity
            .status(HttpStatus.UNAUTHORIZED)
            .body(Map.of("error", "Invalid token"));

    movieService.updateMovie(id, request, managerId);
    return ResponseEntity.ok(Map.of("message", "Movie updated successfully"));
}

@PreAuthorize("hasRole('MANAGER')")
@DeleteMapping("/{id}")
public ResponseEntity<?> deleteMovie(
        @PathVariable Long id,
        HttpServletRequest req) {

    Long managerId = (Long) req.getAttribute("userId");
    if (managerId == null) return ResponseEntity
            .status(HttpStatus.UNAUTHORIZED)
            .body(Map.of("error", "Invalid token"));

    movieService.deleteMovie(id, managerId);
    return ResponseEntity.ok(Map.of("message", "Movie removed successfully"));
}
}