package com.example.movie_booking.Controller;

import com.example.movie_booking.dto.TheaterRequest;
import com.example.movie_booking.dto.TheaterResponse;
import com.example.movie_booking.Service.TheaterService;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.validation.Valid;
import lombok.RequiredArgsConstructor;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.Map;

@RestController
@RequestMapping("/api/theaters")
@RequiredArgsConstructor
public class TheaterController {
    @Autowired
    private final TheaterService theaterService;

    // ── Public ───────────────────────────────────────────────────

    @GetMapping
    public ResponseEntity<List<TheaterResponse>> getAllTheaters() {
        return ResponseEntity.ok(theaterService.getAllTheaters());
    }

    @GetMapping("/city/{city}")
    public ResponseEntity<List<TheaterResponse>> getByCity(@PathVariable String city) {
        return ResponseEntity.ok(theaterService.getTheatersByCity(city));
    }

    @GetMapping("/{id}")
    public ResponseEntity<TheaterResponse> getById(@PathVariable Long id) {
        return ResponseEntity.ok(theaterService.getTheaterById(id));
    }

    // ── Manager only ─────────────────────────────────────────────

    @PreAuthorize("hasRole('MANAGER')")
    @GetMapping("/my-theaters")
    public ResponseEntity<List<TheaterResponse>> getMyTheaters(HttpServletRequest req) {
        Long managerId = (Long) req.getAttribute("userId");
        return ResponseEntity.ok(theaterService.getMyTheaters(managerId));
    }

    @PreAuthorize("hasRole('MANAGER')")
    @PostMapping
    public ResponseEntity<Map<String, Object>> addTheater(
            @Valid @RequestBody TheaterRequest request,
            HttpServletRequest req) {

        Long managerId = (Long) req.getAttribute("userId");
        if (managerId == null) return ResponseEntity
        .status(HttpStatus.UNAUTHORIZED)
        .body(Map.of("error", "Invalid token"));
        Long hallId = theaterService.addTheater(request, managerId);
        return ResponseEntity.ok(Map.of(
                "message", "Theater added successfully",
                "hallId",  hallId
        ));
    }

    @PreAuthorize("hasRole('MANAGER')")
    @PutMapping("/{id}")
    public ResponseEntity<Map<String, String>> updateTheater(
            @PathVariable Long id,
            @Valid @RequestBody TheaterRequest request,
            HttpServletRequest req) {

        Long managerId = (Long) req.getAttribute("userId");
        theaterService.updateTheater(id, request, managerId);
        return ResponseEntity.ok(Map.of("message", "Theater updated successfully"));
    }

    @PreAuthorize("hasRole('MANAGER')")
    @DeleteMapping("/{id}")
    public ResponseEntity<Map<String, String>> deleteTheater(
            @PathVariable Long id,
            HttpServletRequest req) {

        Long managerId = (Long) req.getAttribute("userId");
        theaterService.deleteTheater(id, managerId);
        return ResponseEntity.ok(Map.of("message", "Theater deleted successfully"));
    }
}
