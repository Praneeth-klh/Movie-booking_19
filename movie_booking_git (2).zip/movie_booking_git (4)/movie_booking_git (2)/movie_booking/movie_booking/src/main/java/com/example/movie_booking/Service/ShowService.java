package com.example.movie_booking.Service;

import com.example.movie_booking.dao.*;
import com.example.movie_booking.dto.ShowRequest;
import com.example.movie_booking.dto.ShowResponse;
import com.example.movie_booking.Exception.AppException;
import com.example.movie_booking.Model.*;
import lombok.RequiredArgsConstructor;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Service;

import java.time.LocalDate;
import java.util.List;

@Service
@RequiredArgsConstructor
public class ShowService {

    private final ShowDao    showDao;
    private final MovieDao   movieDao;
    private final ScreenDao  screenDao;
    private final TheaterDao theaterDao;

    public List<ShowResponse> getShowsByMovieAndDate(Long movieId, LocalDate date) {
        return showDao.findByMovieAndDate(movieId, date)
                .stream().map(this::toResponse).toList();
    }

    public ShowResponse getShowById(Long showId) {
        Show show = showDao.findById(showId)
                .orElseThrow(() -> new AppException(
                        "Show not found", HttpStatus.NOT_FOUND));
        return toResponse(show);
    }

    public Long addShow(ShowRequest req, Long managerId) {

        // Verify screen exists
        Screen screen = screenDao.findById(req.getScreenId())
                .orElseThrow(() -> new AppException(
                        "Screen not found", HttpStatus.NOT_FOUND));

        // Verify manager owns the theater
        Theater theater = theaterDao.findById(screen.getHallId())
                .orElseThrow(() -> new AppException(
                        "Theater not found", HttpStatus.NOT_FOUND));

        if (!theater.getManagedBy().equals(managerId)) {
            throw new AppException(
                    "You do not manage this screen's theater",
                    HttpStatus.FORBIDDEN);
        }

        // Verify movie exists
        movieDao.findById(req.getMovieId())
                .orElseThrow(() -> new AppException(
                        "Movie not found", HttpStatus.NOT_FOUND));

        // Check for time conflict
        if (showDao.hasConflict(req.getScreenId(),
                req.getShowDate(), req.getShowTime(), null)) {
            throw new AppException(
                    "A show already exists at this time on this screen",
                    HttpStatus.CONFLICT);
        }

        Show show = new Show(
                null,
                req.getMovieId(),
                req.getScreenId(),
                req.getShowDate(),
                req.getShowTime(),
                req.getPriceSilver(),
                req.getPriceGold(),
                req.getPricePlatinum(),
                true
        );
        return showDao.save(show);
    }

    public void cancelShow(Long showId, Long managerId) {
        Show show = showDao.findById(showId)
                .orElseThrow(() -> new AppException(
                        "Show not found", HttpStatus.NOT_FOUND));

        Screen screen = screenDao.findById(show.getScreenId())
                .orElseThrow(() -> new AppException(
                        "Screen not found", HttpStatus.NOT_FOUND));

        Theater theater = theaterDao.findById(screen.getHallId())
                .orElseThrow(() -> new AppException(
                        "Theater not found", HttpStatus.NOT_FOUND));

        if (!theater.getManagedBy().equals(managerId)) {
            throw new AppException(
                    "You do not manage this show's theater",
                    HttpStatus.FORBIDDEN);
        }

        showDao.softDelete(showId);
    }

    // ── Mapper ────────────────────────────────────────────────────
    private ShowResponse toResponse(Show s) {
        Movie   movie   = movieDao.findById(s.getMovieId()).orElse(null);
        Screen  screen  = screenDao.findById(s.getScreenId()).orElse(null);
        Theater theater = screen != null
                ? theaterDao.findById(screen.getHallId()).orElse(null)
                : null;

        int booked    = showDao.countBookedSeats(s.getShowId());
        int capacity  = screen != null ? screen.getSeatingCapacity() : 0;
        int available = Math.max(0, capacity - booked); // ✅ FIXED

        return new ShowResponse(
                s.getShowId(),
                s.getMovieId(),
                movie   != null ? movie.getTitle()        : "N/A",
                s.getScreenId(),
                screen  != null ? screen.getScreenName()  : "N/A",
                theater != null ? theater.getName()        : "N/A",
                theater != null ? theater.getCity()        : "N/A",
                s.getShowDate(),
                s.getShowTime(),
                s.getPriceSilver(),
                s.getPriceGold(),
                s.getPricePlatinum(),
                available
        );
    }
}