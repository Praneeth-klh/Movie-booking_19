package com.example.movie_booking.dto;

import jakarta.validation.constraints.*;
import lombok.Data;
import java.math.BigDecimal;
import java.time.LocalDate;
import java.time.LocalTime;

@Data
public class ShowRequest {

    @NotNull(message = "Movie ID is required")
    private Long movieId;

    @NotNull(message = "Screen ID is required")
    private Long screenId;

    @NotNull(message = "Show date is required")
    private LocalDate showDate;        // removed @FutureOrPresent for testing

    @NotNull(message = "Show time is required")
    private LocalTime showTime;

    @NotNull @DecimalMin("1.0")
    private BigDecimal priceSilver;

    @NotNull @DecimalMin("1.0")
    private BigDecimal priceGold;

    @NotNull @DecimalMin("1.0")
    private BigDecimal pricePlatinum;
}
