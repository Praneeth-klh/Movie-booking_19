package com.example.movie_booking.security;
import jakarta.servlet.FilterChain;
import jakarta.servlet.ServletException;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import lombok.RequiredArgsConstructor;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.security.core.authority.SimpleGrantedAuthority;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.stereotype.Component;
import org.springframework.web.filter.OncePerRequestFilter;
import com.example.movie_booking.security.*;

import io.jsonwebtoken.Claims;

import java.io.IOException;
import java.util.List;
@Component
@RequiredArgsConstructor
public class JwtAuthFilter extends OncePerRequestFilter {

    private final JwtUtil jwtUtil;

    @Override
    protected void doFilterInternal(HttpServletRequest request,
                                    HttpServletResponse response,
                                    FilterChain filterChain)
            throws ServletException, IOException {
        try {
            String authHeader = request.getHeader("Authorization");

            if (authHeader != null && authHeader.startsWith("Bearer ")) {
                String token = authHeader.substring(7).trim();

                if (jwtUtil.isTokenValid(token)) {
                    Claims claims = jwtUtil.extractClaims(token);

                    String email  = claims.getSubject();
                    String role   = claims.get("role", String.class);

                    // ── Extract userId safely ──────────────────
                    Object userIdObj = claims.get("userId");
                    Long userId = null;
                    if (userIdObj instanceof Integer) {
                        userId = ((Integer) userIdObj).longValue();
                    } else if (userIdObj instanceof Long) {
                        userId = (Long) userIdObj;
                    }

                    // ── Set authentication ─────────────────────
                    UsernamePasswordAuthenticationToken authToken =
                            new UsernamePasswordAuthenticationToken(
                                    email, null,
                                    List.of(new SimpleGrantedAuthority(
                                            "ROLE_" + role))
                            );
                    SecurityContextHolder.getContext()
                                         .setAuthentication(authToken);

                    // ── Set userId on request ──────────────────
                    if (userId != null) {
                        request.setAttribute("userId", userId);
                        System.out.println("JWT Filter — userId set: "
                                + userId + " role: " + role);
                    } else {
                        System.err.println("JWT Filter — userId is NULL in token!");
                    }
                }
            }
        } catch (Exception e) {
            System.err.println("JWT Filter error: " + e.getMessage());
            e.printStackTrace();
        }

        filterChain.doFilter(request, response);
    }
}