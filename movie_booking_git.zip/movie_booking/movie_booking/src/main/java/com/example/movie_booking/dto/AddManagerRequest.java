package com.example.movie_booking.dto;


import jakarta.validation.constraints.*;
import lombok.Data;

@Data
public class AddManagerRequest {

    @NotBlank(message = "Name is required")
    private String name;

    @Email(message = "Invalid email format")
    @NotBlank(message = "Email is required")
    private String email;

    @Size(min = 6, message = "Password must be at least 6 characters")
    @NotBlank(message = "Password is required")
    private String password;
}
