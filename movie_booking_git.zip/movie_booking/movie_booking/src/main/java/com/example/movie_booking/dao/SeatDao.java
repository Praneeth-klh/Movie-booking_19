package com.example.movie_booking.dao;

import com.example.movie_booking.Model.Seat;
import lombok.RequiredArgsConstructor;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.RowMapper;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
@RequiredArgsConstructor
public class SeatDao {

    private final JdbcTemplate jdbcTemplate;

    private final RowMapper<Seat> seatRowMapper = (rs, rowNum) -> new Seat(
            rs.getLong("seat_id"),
            rs.getLong("screen_id"),
            rs.getString("seat_number"),
            rs.getString("seat_class"),
            rs.getBoolean("is_active")
    );

    public List<Seat> findByScreen(Long screenId) {
        String sql = "SELECT * FROM seats WHERE screen_id = ? AND is_active = TRUE ORDER BY seat_number";
        return jdbcTemplate.query(sql, seatRowMapper, screenId);
    }

    public List<Seat> findByIds(List<Long> seatIds) {
        String placeholders = String.join(",", seatIds.stream().map(id -> "?").toList());
        String sql = "SELECT * FROM seats WHERE seat_id IN (" + placeholders + ")";
        return jdbcTemplate.query(sql, seatRowMapper, seatIds.toArray());
    }

    // Batch insert seats for a screen
    public void bulkInsert(Long screenId, List<Seat> seats) {
        String sql = "INSERT INTO seats (screen_id, seat_number, seat_class) VALUES (?, ?, ?)";
        jdbcTemplate.batchUpdate(sql, seats, seats.size(), (ps, seat) -> {
            ps.setLong(1,   screenId);
            ps.setString(2, seat.getSeatNumber());
            ps.setString(3, seat.getSeatClass());
        });
    }

    // Get booked seat IDs for a show
    public List<Long> findBookedSeatIds(Long showId) {
        String sql = """
                SELECT bs.seat_id FROM booking_seats bs
                JOIN bookings b ON bs.booking_id = b.booking_id
                WHERE b.show_id = ? AND b.status != 'CANCELLED'
                """;
        return jdbcTemplate.queryForList(sql, Long.class, showId);
    }
}
