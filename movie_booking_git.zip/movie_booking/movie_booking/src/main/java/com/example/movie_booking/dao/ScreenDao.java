package com.example.movie_booking.dao;
import com.example.movie_booking.Model.Screen;
import lombok.RequiredArgsConstructor;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.RowMapper;
import org.springframework.jdbc.support.GeneratedKeyHolder;
import org.springframework.jdbc.support.KeyHolder;
import org.springframework.stereotype.Repository;

import java.sql.PreparedStatement;
import java.sql.Statement;
import java.util.List;
import java.util.Optional;

@Repository
@RequiredArgsConstructor
public class ScreenDao {

    private final JdbcTemplate jdbcTemplate;

    private final RowMapper<Screen> screenRowMapper = (rs, rowNum) -> new Screen(
            rs.getLong("screen_id"),
            rs.getLong("hall_id"),
            rs.getString("screen_name"),
            rs.getInt("seating_capacity"),
            rs.getString("screen_type"),
            rs.getBoolean("is_active")
    );

    // ── All screens for a hall ───────────────────────────────────
    public List<Screen> findByHallId(Long hallId) {
        String sql = "SELECT * FROM screens WHERE hall_id = ? AND is_active = TRUE";
        return jdbcTemplate.query(sql, screenRowMapper, hallId);
    }

    // ── Single screen by ID ──────────────────────────────────────
    public Optional<Screen> findById(Long screenId) {
        String sql = "SELECT * FROM screens WHERE screen_id = ?";
        return jdbcTemplate.query(sql, screenRowMapper, screenId)
                .stream().findFirst();
    }

    // ── Verify screen belongs to a hall ─────────────────────────
    public boolean belongsToHall(Long screenId, Long hallId) {
        String sql = "SELECT COUNT(*) FROM screens WHERE screen_id = ? AND hall_id = ?";
        Integer count = jdbcTemplate.queryForObject(sql, Integer.class, screenId, hallId);
        return count != null && count > 0;
    }

    // ── Insert ───────────────────────────────────────────────────
    public Long save(Screen screen) {
        String sql = """
                INSERT INTO screens (hall_id, screen_name, seating_capacity, screen_type, is_active)
                VALUES (?, ?, ?, ?, TRUE)
                """;
        KeyHolder keyHolder = new GeneratedKeyHolder();
        jdbcTemplate.update(conn -> {
            PreparedStatement ps = conn.prepareStatement(sql, Statement.RETURN_GENERATED_KEYS);
            ps.setLong(1,   screen.getHallId());
            ps.setString(2, screen.getScreenName());
            ps.setInt(3,    screen.getSeatingCapacity());
            ps.setString(4, screen.getScreenType());
            return ps;
        }, keyHolder);
        return keyHolder.getKey().longValue();
    }

    // ── Update ───────────────────────────────────────────────────
    public int update(Screen screen) {
        String sql = """
                UPDATE screens SET
                    screen_name      = ?,
                    seating_capacity = ?,
                    screen_type      = ?
                WHERE screen_id = ? AND hall_id = ?
                """;
        return jdbcTemplate.update(sql,
                screen.getScreenName(), screen.getSeatingCapacity(),
                screen.getScreenType(),
                screen.getScreenId(), screen.getHallId());
    }

    // ── Soft delete ──────────────────────────────────────────────
    public int softDelete(Long screenId, Long hallId) {
        String sql = "UPDATE screens SET is_active = FALSE WHERE screen_id = ? AND hall_id = ?";
        return jdbcTemplate.update(sql, screenId, hallId);
    }
}
