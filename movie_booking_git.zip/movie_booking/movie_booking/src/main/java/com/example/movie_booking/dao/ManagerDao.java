package com.example.movie_booking.dao;

import com.example.movie_booking.dto.ManagerResponse;
import lombok.RequiredArgsConstructor;
import org.springframework.jdbc.core.JdbcTemplate;
import com.example.movie_booking.Model.User;
import org.springframework.stereotype.Repository;

import javax.swing.tree.RowMapper;
import java.util.List;
@Repository
@RequiredArgsConstructor
public class ManagerDao {
    private final JdbcTemplate jdbcTemplate;

    private final RowMapper<ManagerResponse> managerRowMapper = (rs, rowNum) ->
            new ManagerResponse(
                    rs.getLong("user_id"),
                    rs.getString("name"),
                    rs.getString("email"),
                    rs.getString("created_at")
            );

    public List<ManagerResponse> findAllManagers() {
        String sql = "SELECT user_id, name, email, created_at FROM users WHERE role = 'MANAGER'";
        return jdbcTemplate.query(sql, managerRowMapper);
    }

    public boolean existsByEmail(String email) {
        String sql = "SELECT COUNT(*) FROM users WHERE email = ?";
        Integer count = jdbcTemplate.queryForObject(sql, Integer.class, email);
        return count != null && count > 0;
    }

    public void saveManager(User user) {
        String sql = "INSERT INTO users (name, email, password, role) VALUES (?, ?, ?, 'MANAGER')";
        jdbcTemplate.update(sql, user.getName(), user.getEmail(), user.getPassword());
    }

    public int removeManager(Long managerId) {
        // Only removes if user is actually a MANAGER (safety check)
        String sql = "DELETE FROM users WHERE user_id = ? AND role = 'MANAGER'";
        return jdbcTemplate.update(sql, managerId);
    }
}
