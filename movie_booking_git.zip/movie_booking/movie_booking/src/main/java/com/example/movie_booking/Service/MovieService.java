package com.example.movie_booking.Service;
import lombok.RequiredArgsConstructor;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Service;

import java.util.List;
import com.example.movie_booking.dao.MovieDao;
import com.example.movie_booking.dto.MovieRequest;
import com.example.movie_booking.Model.Movie;
import com.example.movie_booking.Exception.AppException;
@Service
@RequiredArgsConstructor
public class MovieService {
        private final MovieDao movieDao;

        // ── Public: all users ────────────────────────────────────────
        public List<Movie> getAllMovies() {
            return movieDao.findAllActive();
        }

        public Movie getMovieById(Long id) {
            return movieDao.findById(id)
                    .orElseThrow(() -> new AppException("Movie not found", HttpStatus.NOT_FOUND));
        }

        public List<Movie> searchMovies(String keyword) {
            return movieDao.search(keyword);
        }

        // ── Manager only ─────────────────────────────────────────────
        public void addMovie(MovieRequest req, Long managerId) {
            Movie movie = new Movie(
                    null,
                    req.getTitle(), req.getGenre(),
                    req.getDuration(), req.getReleaseDate(),
                    req.getLanguage(), req.getRating(),
                    req.getPosterUrl(), req.getDescription(),
                    true, managerId
            );
            movieDao.save(movie);
        }

        public void updateMovie(Long movieId, MovieRequest req, Long managerId) {
            // Verify movie exists
            Movie existing = movieDao.findById(movieId)
                    .orElseThrow(() -> new AppException("Movie not found", HttpStatus.NOT_FOUND));

            Movie updated = new Movie(
                    movieId,
                    req.getTitle(), req.getGenre(),
                    req.getDuration(), req.getReleaseDate(),
                    req.getLanguage(), req.getRating(),
                    req.getPosterUrl(), req.getDescription(),
                    true, managerId
            );

            int rows = movieDao.update(updated);
            if (rows == 0) {
                // 0 rows = manager doesn't own this movie
                throw new AppException("You are not authorized to update this movie", HttpStatus.FORBIDDEN);
            }
        }

        public void deleteMovie(Long movieId, Long managerId) {
            movieDao.findById(movieId)
                    .orElseThrow(() -> new AppException("Movie not found", HttpStatus.NOT_FOUND));

            int rows = movieDao.softDelete(movieId, managerId);
            if (rows == 0) {
                throw new AppException("You are not authorized to delete this movie", HttpStatus.FORBIDDEN);
            }
        }

        public List<Movie> getMyMovies(Long managerId) {
            return movieDao.findByManager(managerId);
        }
    }
