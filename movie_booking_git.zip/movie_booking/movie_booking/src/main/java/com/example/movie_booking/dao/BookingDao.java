package com.example.movie_booking.dao;


import com.example.movie_booking.Model.Booking;
import lombok.RequiredArgsConstructor;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.RowMapper;
import org.springframework.jdbc.support.GeneratedKeyHolder;
import org.springframework.jdbc.support.KeyHolder;
import org.springframework.stereotype.Repository;

import java.sql.PreparedStatement;
import java.sql.Statement;
import java.sql.Timestamp;
import java.util.List;
import java.util.Optional;

@Repository
@RequiredArgsConstructor
public class BookingDao {

    private final JdbcTemplate jdbcTemplate;

    private final RowMapper<Booking> bookingRowMapper = (rs, rowNum) -> new Booking(
            rs.getLong("booking_id"),
            rs.getLong("user_id"),
            rs.getLong("show_id"),
            rs.getBigDecimal("total_amount"),
            rs.getBigDecimal("delivery_charge"),
            rs.getString("status"),
            rs.getString("payment_mode"),
            rs.getString("payment_ref"),
            rs.getTimestamp("booking_time").toLocalDateTime()
    );

    public Long save(Booking booking) {
        String sql = """
                INSERT INTO bookings
                (user_id, show_id, total_amount, delivery_charge,
                 status, payment_mode, payment_ref)
                VALUES (?, ?, ?, ?, ?, ?, ?)
                """;
        KeyHolder kh = new GeneratedKeyHolder();
        jdbcTemplate.update(conn -> {
            PreparedStatement ps = conn.prepareStatement(sql, Statement.RETURN_GENERATED_KEYS);
            ps.setLong(1,         booking.getUserId());
            ps.setLong(2,         booking.getShowId());
            ps.setBigDecimal(3,   booking.getTotalAmount());
            ps.setBigDecimal(4,   booking.getDeliveryCharge());
            ps.setString(5,       booking.getStatus());
            ps.setString(6,       booking.getPaymentMode());
            ps.setString(7,       booking.getPaymentRef());
            return ps;
        }, kh);
        return kh.getKey().longValue();
    }

    public void saveBookingSeats(Long bookingId, List<Long> seatIds) {
        String sql = "INSERT INTO booking_seats (booking_id, seat_id) VALUES (?, ?)";
        jdbcTemplate.batchUpdate(sql, seatIds, seatIds.size(), (ps, seatId) -> {
            ps.setLong(1, bookingId);
            ps.setLong(2, seatId);
        });
    }

    public Optional<Booking> findById(Long bookingId) {
        String sql = "SELECT * FROM bookings WHERE booking_id = ?";
        return jdbcTemplate.query(sql, bookingRowMapper, bookingId).stream().findFirst();
    }

    public List<Booking> findByUser(Long userId) {
        String sql = "SELECT * FROM bookings WHERE user_id = ? ORDER BY booking_time DESC";
        return jdbcTemplate.query(sql, bookingRowMapper, userId);
    }

    public List<Long> findSeatIdsByBooking(Long bookingId) {
        String sql = "SELECT seat_id FROM booking_seats WHERE booking_id = ?";
        return jdbcTemplate.queryForList(sql, Long.class, bookingId);
    }

    public int updateStatus(Long bookingId, String status) {
        return jdbcTemplate.update(
                "UPDATE bookings SET status = ? WHERE booking_id = ?", status, bookingId);
    }
}
