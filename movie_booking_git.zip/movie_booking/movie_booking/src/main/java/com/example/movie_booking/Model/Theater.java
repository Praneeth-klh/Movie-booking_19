package com.example.movie_booking.Model;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
@Data
@NoArgsConstructor
@AllArgsConstructor
public class Theater {
        private Long   hallId;
        private String name;
        private String type;
        private String location;
        private String city;
        private String facilities;
        private String mapUrl;
        private boolean isActive;
        private Long   managedBy;
}
