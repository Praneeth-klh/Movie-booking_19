package com.example.movie_booking.dto;

import lombok.AllArgsConstructor;
import lombok.Data;

@Data
@AllArgsConstructor
public class ScreenResponse {
    private Long   screenId;
    private String screenName;
    private int    seatingCapacity;
    private String screenType;
}

