package com.example.movie_booking.dto;



import lombok.AllArgsConstructor;
import lombok.Data;
import java.math.BigDecimal;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.LocalTime;
import java.util.List;

@Data
@AllArgsConstructor
public class BookingResponse {
    private Long          bookingId;
    private String        movieTitle;
    private String        theaterName;
    private String        screenName;
    private LocalDate     showDate;
    private LocalTime     showTime;
    private List<String>  seatNumbers;
    private BigDecimal    subtotal;
    private BigDecimal    deliveryCharge;
    private BigDecimal    totalAmount;
    private String        paymentMode;
    private String        paymentRef;
    private String        status;
    private LocalDateTime bookingTime;
}
