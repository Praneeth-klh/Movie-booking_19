package com.example.movie_booking.Service;
import com.moviebooking.dao.ScreenDao;
import com.moviebooking.dao.TheaterDao;
import com.moviebooking.dto.*;
import com.moviebooking.exception.AppException;
import com.moviebooking.model.Screen;
import com.moviebooking.model.Theater;
import lombok.RequiredArgsConstructor;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
@RequiredArgsConstructor
public class TheaterService {

    private final TheaterDao theaterDao;
    private final ScreenDao  screenDao;

    // ── Public ───────────────────────────────────────────────────
    public List<TheaterResponse> getAllTheaters() {
        return theaterDao.findAllActive()
                .stream()
                .map(this::toResponse)
                .toList();
    }

    public List<TheaterResponse> getTheatersByCity(String city) {
        return theaterDao.findByCity(city)
                .stream()
                .map(this::toResponse)
                .toList();
    }

    public TheaterResponse getTheaterById(Long hallId) {
        Theater theater = theaterDao.findById(hallId)
                .orElseThrow(() -> new AppException("Theater not found", HttpStatus.NOT_FOUND));
        return toResponse(theater);
    }

    // ── Manager only ─────────────────────────────────────────────
    public List<TheaterResponse> getMyTheaters(Long managerId) {
        return theaterDao.findByManager(managerId)
                .stream()
                .map(this::toResponse)
                .toList();
    }

    public Long addTheater(TheaterRequest req, Long managerId) {
        Theater theater = new Theater(
                null, req.getName(), req.getType(),
                req.getLocation(), req.getCity(),
                req.getFacilities(), req.getMapUrl(),
                true, managerId
        );
        return theaterDao.save(theater);
    }

    public void updateTheater(Long hallId, TheaterRequest req, Long managerId) {
        theaterDao.findById(hallId)
                .orElseThrow(() -> new AppException("Theater not found", HttpStatus.NOT_FOUND));

        Theater theater = new Theater(
                hallId, req.getName(), req.getType(),
                req.getLocation(), req.getCity(),
                req.getFacilities(), req.getMapUrl(),
                true, managerId
        );
        int rows = theaterDao.update(theater);
        if (rows == 0) {
            throw new AppException("You are not authorized to update this theater", HttpStatus.FORBIDDEN);
        }
    }

    public void deleteTheater(Long hallId, Long managerId) {
        theaterDao.findById(hallId)
                .orElseThrow(() -> new AppException("Theater not found", HttpStatus.NOT_FOUND));

        int rows = theaterDao.softDelete(hallId, managerId);
        if (rows == 0) {
            throw new AppException("You are not authorized to delete this theater", HttpStatus.FORBIDDEN);
        }
    }

    // ── Helper: Theater → TheaterResponse (with nested screens) ──
    private TheaterResponse toResponse(Theater t) {
        List<ScreenResponse> screens = screenDao.findByHallId(t.getHallId())
                .stream()
                .map(s -> new ScreenResponse(
                        s.getScreenId(), s.getScreenName(),
                        s.getSeatingCapacity(), s.getScreenType()))
                .toList();

        return new TheaterResponse(
                t.getHallId(), t.getName(), t.getType(),
                t.getLocation(), t.getCity(),
                t.getFacilities(), t.getMapUrl(),
                screens
        );
    }
}