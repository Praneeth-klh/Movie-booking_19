package com.example.movie_booking.Controller;
import com.example.movie_booking.Service.AdminService;
import com.example.movie_booking.dto.AddManagerRequest;
import com.example.movie_booking.dto.ManagerResponse;
import jakarta.validation.Valid;
import lombok.RequiredArgsConstructor;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.*;
import java.util.List;
import java.util.Map;
@RestController
@RequestMapping("/api/admin")
@PreAuthorize("hasRole('ADMIN')")   // entire controller is ADMIN only
@RequiredArgsConstructor
public class AdminController {
    private final AdminService adminService;

    @GetMapping("/managers")
    public ResponseEntity<List<ManagerResponse>> getAllManagers() {
        return ResponseEntity.ok(adminService.getAllManagers());
    }

    @PostMapping("/managers")
    public ResponseEntity<Map<String, String>> addManager(
            @Valid @RequestBody AddManagerRequest request) {
        adminService.addManager(request);
        return ResponseEntity.ok(Map.of("message", "Manager added successfully"));
    }

    @DeleteMapping("/managers/{id}")
    public ResponseEntity<Map<String, String>> removeManager(@PathVariable Long id) {
        adminService.removeManager(id);
        return ResponseEntity.ok(Map.of("message", "Manager removed successfully"));
    }
}
