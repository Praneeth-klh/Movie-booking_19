package com.example.movie_booking.Service;
import lombok.RequiredArgsConstructor;
import org.springframework.http.HttpStatus;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Service;
import com.example.movie_booking.dao.UserDao;
import com.example.movie_booking.dto.*;
import com.example.movie_booking.Exception.AppException;
import com.example.movie_booking.security.JwtUtil;
import com.example.movie_booking.Model.User;
@Service
@RequiredArgsConstructor

public class AuthService {
        private final UserDao userDao;
        private final JwtUtil jwtUtil;
        private final PasswordEncoder passwordEncoder;

        public AuthResponse register(RegisterRequest request) {

            if (userDao.existsByEmail(request.getEmail())) {
                throw new AppException("Email already registered", HttpStatus.CONFLICT);
            }

            // Prevent self-assignment of ADMIN role
            String role = request.getRole().equalsIgnoreCase("ADMIN") ? "USER" : request.getRole().toUpperCase();

            User user = new User(
                    null,
                    request.getName(),
                    request.getEmail(),
                    passwordEncoder.encode(request.getPassword()),
                    role
            );
            userDao.save(user);

            // Fetch saved user to get generated ID
            User saved = userDao.findByEmail(request.getEmail())
                    .orElseThrow(() -> new AppException("Registration failed", HttpStatus.INTERNAL_SERVER_ERROR));

            String token = jwtUtil.generateToken(saved.getEmail(), saved.getRole(), saved.getUserId());
            return new AuthResponse(token, saved.getRole(), saved.getName(), saved.getUserId());
        }

        public AuthResponse login(LoginRequest request) {

            User user = userDao.findByEmail(request.getEmail())
                    .orElseThrow(() -> new AppException("Invalid email or password", HttpStatus.UNAUTHORIZED));

            if (!passwordEncoder.matches(request.getPassword(), user.getPassword())) {
                throw new AppException("Invalid email or password", HttpStatus.UNAUTHORIZED);
            }

            String token = jwtUtil.generateToken(user.getEmail(), user.getRole(), user.getUserId());
            return new AuthResponse(token, user.getRole(), user.getName(), user.getUserId());
        }
    }
