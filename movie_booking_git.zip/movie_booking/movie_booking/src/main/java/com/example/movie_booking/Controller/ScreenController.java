package com.example.movie_booking.Controller;



import com.example.movie_booking.dto.ScreenRequest;
import com.example.movie_booking.dto.ScreenResponse;
import com.example.movie_booking.Service.ScreenService;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.validation.Valid;
import lombok.RequiredArgsConstructor;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.Map;

@RestController
@RequestMapping("/api/theaters/{hallId}/screens")
@RequiredArgsConstructor
public class ScreenController {

    private ScreenService screenService;

    // ── Public ───────────────────────────────────────────────────

    @GetMapping
    public ResponseEntity<List<ScreenResponse>> getScreens(@PathVariable Long hallId) {
        return ResponseEntity.ok(screenService.getScreensByHall(hallId));
    }

    // ── Manager only ─────────────────────────────────────────────

    @PreAuthorize("hasRole('MANAGER')")
    @PostMapping
    public ResponseEntity<Map<String, Object>> addScreen(
            @PathVariable Long hallId,
            @Valid @RequestBody ScreenRequest request,
            HttpServletRequest req) {

        Long managerId = (Long) req.getAttribute("userId");
        Long screenId = screenService.addScreen(hallId, request, managerId);
        return ResponseEntity.ok(Map.of(
                "message",  "Screen added successfully",
                "screenId", screenId
        ));
    }

    @PreAuthorize("hasRole('MANAGER')")
    @PutMapping("/{screenId}")
    public ResponseEntity<Map<String, String>> updateScreen(
            @PathVariable Long hallId,
            @PathVariable Long screenId,
            @Valid @RequestBody ScreenRequest request,
            HttpServletRequest req) {

        Long managerId = (Long) req.getAttribute("userId");
        screenService.updateScreen(hallId, screenId, request, managerId);
        return ResponseEntity.ok(Map.of("message", "Screen updated successfully"));
    }

    @PreAuthorize("hasRole('MANAGER')")
    @DeleteMapping("/{screenId}")
    public ResponseEntity<Map<String, String>> deleteScreen(
            @PathVariable Long hallId,
            @PathVariable Long screenId,
            HttpServletRequest req) {

        Long managerId = (Long) req.getAttribute("userId");
        screenService.deleteScreen(hallId, screenId, managerId);
        return ResponseEntity.ok(Map.of("message", "Screen deleted successfully"));
    }
}
