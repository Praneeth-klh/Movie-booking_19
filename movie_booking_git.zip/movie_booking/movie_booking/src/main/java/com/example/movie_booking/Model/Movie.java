package com.example.movie_booking.Model;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.time.LocalDate;
@Data
@NoArgsConstructor
@AllArgsConstructor
public class Movie {
    private Long   movieId;
    private String title;
    private String genre;
    private int    duration;
    private LocalDate releaseDate;
    private String language;
    private String rating;
    private String posterUrl;
    private String description;
    private boolean isActive;
    private Long   createdBy;
}
