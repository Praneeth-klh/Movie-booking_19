package com.example.movie_booking.dto;
import lombok.AllArgsConstructor;
import lombok.Data;
import java.util.List;
@Data
@AllArgsConstructor
public class TheaterResponse {
        private Long hallId;
        private String name;
        private String type;
        private String location;
        private String city;
        private String facilities;
        private String mapUrl;
        private List<ScreenResponse> screens;  // nested screens
}
