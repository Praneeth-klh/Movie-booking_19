package com.example.movie_booking.Service;
import lombok.RequiredArgsConstructor;
import org.springframework.http.HttpStatus;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Service;
import com.example.movie_booking.dao.ManagerDao;
import com.example.movie_booking.dto.AddManagerRequest;
import com.example.movie_booking.dto.ManagerResponse;
import com.example.movie_booking.Exception.AppException;
import com.example.movie_booking.Model.User;

import java.util.List;
@Service
@RequiredArgsConstructor
public class AdminService {

        private final ManagerDao managerDao;
        private final PasswordEncoder passwordEncoder;

        public List<ManagerResponse> getAllManagers() {
            return managerDao.findAllManagers();
        }

        public void addManager(AddManagerRequest req) {
            if (managerDao.existsByEmail(req.getEmail())) {
                throw new AppException("Email already in use", HttpStatus.CONFLICT);
            }
            User manager = new User(
                    null,
                    req.getName(),
                    req.getEmail(),
                    passwordEncoder.encode(req.getPassword()),
                    "MANAGER"
            );
            managerDao.saveManager(manager);
        }

        public void removeManager(Long managerId) {
            int rows = managerDao.removeManager(managerId);
            if (rows == 0) {
                throw new AppException("Manager not found", HttpStatus.NOT_FOUND);
            }
        }
}
