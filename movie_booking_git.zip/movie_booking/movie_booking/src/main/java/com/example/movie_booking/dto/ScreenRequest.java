package com.example.movie_booking.dto;
import jakarta.validation.constraints.*;
import lombok.Data;

@Data
public class ScreenRequest {

        @NotBlank(message = "Screen name is required")
        private String screenName;

        @Min(value = 1, message = "Seating capacity must be at least 1")
        private int seatingCapacity;

        @Pattern(regexp = "2D|3D|IMAX|4DX", message = "Screen type must be 2D, 3D, IMAX or 4DX")
        private String screenType;
    }
