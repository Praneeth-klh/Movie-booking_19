package com.example.movie_booking.dto;
import lombok.Data;
import java.time.LocalDate;
import jakarta.validation.constraints.*;
@Data
public class MovieRequest {
        @NotBlank(message = "Title is required")
        private String title;

        @NotBlank(message = "Genre is required")
        private String genre;

        @Min(value = 1, message = "Duration must be at least 1 minute")
        private int duration;

        @NotNull(message = "Release date is required")
        private LocalDate releaseDate;

        @NotBlank(message = "Language is required")
        private String language;

        private String rating;       // U / UA / A
        private String posterUrl;
        private String description;
    }
