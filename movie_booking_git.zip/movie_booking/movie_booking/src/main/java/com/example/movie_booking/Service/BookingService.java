package com.example.movie_booking.Service;


import com.example.movie_booking.dao.*;
import com.example.movie_booking.dto.*;
import com.example.movie_booking.Exception.AppException;
import com.example.movie_booking.Model.*;
import lombok.RequiredArgsConstructor;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Service;

import java.math.BigDecimal;
import java.util.*;
import java.util.stream.Collectors;

@Service
@RequiredArgsConstructor
public class BookingService {

    private static final BigDecimal DELIVERY_CHARGE = new BigDecimal("20.00");

    private final BookingDao   bookingDao;
    private final SeatDao      seatDao;
    private final SeatLockDao  seatLockDao;
    private final ShowDao      showDao;
    private final ScreenDao    screenDao;
    private final MovieDao     movieDao;
    private final TheatreDao.TheaterDao theaterDao;
    private final PaymentService paymentService;
    private final EmailService emailService;

    public BookingResponse createBooking(BookingRequest request, Long userId) {

        Show show = showDao.findById(request.getShowId())
                .orElseThrow(() -> new AppException("Show not found", HttpStatus.NOT_FOUND));

        List<Seat> seats = seatDao.findByIds(request.getSeatIds());
        if (seats.size() != request.getSeatIds().size()) {
            throw new AppException("One or more seats not found", HttpStatus.BAD_REQUEST);
        }

        // Verify seats are still locked by this user
        List<Long> conflicting = seatLockDao.findConflictingLocks(
                request.getShowId(), request.getSeatIds(), userId);
        if (!conflicting.isEmpty()) {
            throw new AppException(
                    "Some seats are no longer held for you. Please re-select.",
                    HttpStatus.CONFLICT);
        }

        // Verify none are already booked (double booking prevention)
        Set<Long> bookedIds = new HashSet<>(seatDao.findBookedSeatIds(request.getShowId()));
        List<Long> alreadyBooked = request.getSeatIds().stream()
                .filter(bookedIds::contains).toList();
        if (!alreadyBooked.isEmpty()) {
            throw new AppException("Seats already booked: " + alreadyBooked, HttpStatus.CONFLICT);
        }

        // Calculate total based on seat class
        BigDecimal subtotal = seats.stream()
                .map(seat -> priceForClass(seat.getSeatClass(), show))
                .reduce(BigDecimal.ZERO, BigDecimal::add);

        BigDecimal total = subtotal.add(DELIVERY_CHARGE);

        // Process payment
        PaymentService.PaymentResult payment =
                paymentService.process(request.getPaymentMode(), total.doubleValue());

        if (!payment.success()) {
            throw new AppException("Payment failed. Please try again.", HttpStatus.PAYMENT_REQUIRED);
        }

        // Save booking
        Booking booking = new Booking(null, userId, request.getShowId(),
                total, DELIVERY_CHARGE, "CONFIRMED",
                request.getPaymentMode(), payment.paymentRef(), null);

        Long bookingId = bookingDao.save(booking);
        bookingDao.saveBookingSeats(bookingId, request.getSeatIds());

        // Release seat locks
        seatLockDao.releaseLocks(request.getShowId(), request.getSeatIds(), userId);

        BookingResponse response = buildResponse(bookingId);

        // Send confirmation email (async)
        emailService.sendBookingConfirmation(userId, response);

        return response;
    }

    public List<BookingResponse> getMyBookings(Long userId) {
        return bookingDao.findByUser(userId)
                .stream().map(b -> buildResponse(b.getBookingId())).toList();
    }

    public BookingResponse getBookingById(Long bookingId, Long userId) {
        Booking booking = bookingDao.findById(bookingId)
                .orElseThrow(() -> new AppException("Booking not found", HttpStatus.NOT_FOUND));

        if (!booking.getUserId().equals(userId)) {
            throw new AppException("Access denied", HttpStatus.FORBIDDEN);
        }
        return buildResponse(bookingId);
    }

    public void cancelBooking(Long bookingId, Long userId) {
        Booking booking = bookingDao.findById(bookingId)
                .orElseThrow(() -> new AppException("Booking not found", HttpStatus.NOT_FOUND));

        if (!booking.getUserId().equals(userId)) {
            throw new AppException("Access denied", HttpStatus.FORBIDDEN);
        }
        if ("CANCELLED".equals(booking.getStatus())) {
            throw new AppException("Booking already cancelled", HttpStatus.BAD_REQUEST);
        }
        bookingDao.updateStatus(bookingId, "CANCELLED");
    }

    // ── Helpers ───────────────────────────────────────────────────
    private BigDecimal priceForClass(String seatClass, Show show) {
        return switch (seatClass) {
            case "GOLD"     -> show.getPriceGold();
            case "PLATINUM" -> show.getPricePlatinum();
            default         -> show.getPriceSilver();
        };
    }

    private BookingResponse buildResponse(Long bookingId) {
        Booking booking = bookingDao.findById(bookingId).orElseThrow();
        Show    show    = showDao.findById(booking.getShowId()).orElseThrow();
        Screen  screen  = screenDao.findById(show.getScreenId()).orElseThrow();
        Theater theater = theaterDao.findById(screen.getHallId()).orElseThrow();
        Movie   movie   = movieDao.findById(show.getMovieId()).orElseThrow();

        List<Long>   seatIds  = bookingDao.findSeatIdsByBooking(bookingId);
        List<String> seatNums = seatDao.findByIds(seatIds).stream()
                .map(Seat::getSeatNumber).toList();

        BigDecimal subtotal = booking.getTotalAmount().subtract(booking.getDeliveryCharge());

        return new BookingResponse(
                booking.getBookingId(),
                movie.getTitle(), theater.getName(), screen.getScreenName(),
                show.getShowDate(), show.getShowTime(),
                seatNums,
                subtotal, booking.getDeliveryCharge(), booking.getTotalAmount(),
                booking.getPaymentMode(), booking.getPaymentRef(),
                booking.getStatus(), booking.getBookingTime()
        );
    }
}