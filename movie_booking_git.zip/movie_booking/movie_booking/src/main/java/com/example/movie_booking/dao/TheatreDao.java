package com.example.movie_booking.dao;
import com.example.movie_booking.Model.Theater;
import lombok.RequiredArgsConstructor;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.RowMapper;
import org.springframework.jdbc.support.GeneratedKeyHolder;
import org.springframework.jdbc.support.KeyHolder;
import org.springframework.stereotype.Repository;
import java.sql.PreparedStatement;
import java.sql.Statement;
import java.util.List;
import java.util.Optional;

public class TheatreDao {

    @Repository
    @RequiredArgsConstructor
    public class TheaterDao {

        private final JdbcTemplate jdbcTemplate;

        private final RowMapper<Theater> theaterRowMapper = (rs, rowNum) -> new Theater(
                rs.getLong("hall_id"),
                rs.getString("name"),
                rs.getString("type"),
                rs.getString("location"),
                rs.getString("city"),
                rs.getString("facilities"),
                rs.getString("map_url"),
                rs.getBoolean("is_active"),
                rs.getLong("managed_by")
        );

        // ── Get all active theaters ──────────────────────────────────
        public List<Theater> findAllActive() {
            String sql = "SELECT * FROM cinema_halls WHERE is_active = TRUE ORDER BY name";
            return jdbcTemplate.query(sql, theaterRowMapper);
        }

        // ── Get by city ──────────────────────────────────────────────
        public List<Theater> findByCity(String city) {
            String sql = "SELECT * FROM cinema_halls WHERE city = ? AND is_active = TRUE";
            return jdbcTemplate.query(sql, theaterRowMapper, city);
        }

        // ── Get theaters managed by a specific manager ───────────────
        public List<Theater> findByManager(Long managerId) {
            String sql = "SELECT * FROM cinema_halls WHERE managed_by = ? AND is_active = TRUE";
            return jdbcTemplate.query(sql, theaterRowMapper, managerId);
        }

        // ── Get by ID ────────────────────────────────────────────────
        public Optional<Theater> findById(Long hallId) {
            String sql = "SELECT * FROM cinema_halls WHERE hall_id = ?";
            return jdbcTemplate.query(sql, theaterRowMapper, hallId)
                    .stream().findFirst();
        }

        // ── Insert and return generated ID ───────────────────────────
        public Long save(Theater theater) {
            String sql = """
                INSERT INTO cinema_halls
                (name, type, location, city, facilities, map_url, is_active, managed_by)
                VALUES (?, ?, ?, ?, ?, ?, TRUE, ?)
                """;
            KeyHolder keyHolder = new GeneratedKeyHolder();
            jdbcTemplate.update(conn -> {
                PreparedStatement ps = conn.prepareStatement(sql, Statement.RETURN_GENERATED_KEYS);
                ps.setString(1, theater.getName());
                ps.setString(2, theater.getType());
                ps.setString(3, theater.getLocation());
                ps.setString(4, theater.getCity());
                ps.setString(5, theater.getFacilities());
                ps.setString(6, theater.getMapUrl());
                ps.setLong(7,   theater.getManagedBy());
                return ps;
            }, keyHolder);
            return keyHolder.getKey().longValue();
        }

        // ── Update ───────────────────────────────────────────────────
        public int update(Theater theater) {
            String sql = """
                UPDATE cinema_halls SET
                    name       = ?,
                    type       = ?,
                    location   = ?,
                    city       = ?,
                    facilities = ?,
                    map_url    = ?
                WHERE hall_id = ? AND managed_by = ?
                """;
            return jdbcTemplate.update(sql,
                    theater.getName(), theater.getType(),
                    theater.getLocation(), theater.getCity(),
                    theater.getFacilities(), theater.getMapUrl(),
                    theater.getHallId(), theater.getManagedBy());
        }

        // ── Soft delete ──────────────────────────────────────────────
        public int softDelete(Long hallId, Long managerId) {
            String sql = "UPDATE cinema_halls SET is_active = FALSE WHERE hall_id = ? AND managed_by = ?";
            return jdbcTemplate.update(sql, hallId, managerId);
        }
    }
}
