package com.example.movie_booking.Model;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@AllArgsConstructor
public class Seat {
    private Long   seatId;
    private Long   screenId;
    private String seatNumber;
    private String seatClass;   // SILVER / GOLD / PLATINUM
    private boolean isActive;
}
