package com.example.movie_booking.Model;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
@Data
@NoArgsConstructor
@AllArgsConstructor
public class Screen {
        private Long   screenId;
        private Long   hallId;
        private String screenName;
        private int    seatingCapacity;
        private String screenType;    // 2D / 3D / IMAX / 4DX
        private boolean isActive;
    }

