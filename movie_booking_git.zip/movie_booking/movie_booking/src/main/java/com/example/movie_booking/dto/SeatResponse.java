package com.example.movie_booking.dto;


import lombok.AllArgsConstructor;
import lombok.Data;

@Data
@AllArgsConstructor
public class SeatResponse {
    private Long   seatId;
    private String seatNumber;
    private String seatClass;
    private String status;      // AVAILABLE / BOOKED / LOCKED / SELECTED
}
