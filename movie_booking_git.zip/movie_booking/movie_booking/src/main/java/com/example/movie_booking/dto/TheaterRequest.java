package com.example.movie_booking.dto;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.Pattern;
import lombok.Data;
@Data
public class TheaterRequest {

        @NotBlank(message = "Theater name is required")
        private String name;

        @Pattern(regexp = "MULTIPLEX|SINGLE", message = "Type must be MULTIPLEX or SINGLE")
        private String type;

        @NotBlank(message = "Location is required")
        private String location;

        @NotBlank(message = "City is required")
        private String city;

        private String facilities;
        private String mapUrl;
    }
