package com.example.movie_booking.dao;
import com.example.movie_booking.Model.Movie;
import lombok.RequiredArgsConstructor;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.RowMapper;
import org.springframework.stereotype.Repository;

import java.util.List;
import java.util.Optional;
@Repository
@RequiredArgsConstructor
public class MovieDao {
        private final JdbcTemplate jdbcTemplate;

        private final RowMapper<Movie> movieRowMapper = (rs, rowNum) -> new Movie(
                rs.getLong("movie_id"),
                rs.getString("title"),
                rs.getString("genre"),
                rs.getInt("duration"),
                rs.getDate("release_date").toLocalDate(),
                rs.getString("language"),
                rs.getString("rating"),
                rs.getString("poster_url"),
                rs.getString("description"),
                rs.getBoolean("is_active"),
                rs.getLong("created_by")
        );

        // ── Fetch all active movies ──────────────────────────────────
        public List<Movie> findAllActive() {
            String sql = "SELECT * FROM movies WHERE is_active = TRUE ORDER BY created_at DESC";
            return jdbcTemplate.query(sql, movieRowMapper);
        }

        // ── Fetch all movies by a specific manager ───────────────────
        public List<Movie> findByManager(Long managerId) {
            String sql = "SELECT * FROM movies WHERE created_by = ? ORDER BY created_at DESC";
            return jdbcTemplate.query(sql, movieRowMapper, managerId);
        }

        // ── Fetch by ID ──────────────────────────────────────────────
        public Optional<Movie> findById(Long movieId) {
            String sql = "SELECT * FROM movies WHERE movie_id = ?";
            return jdbcTemplate.query(sql, movieRowMapper, movieId)
                    .stream().findFirst();
        }

        // ── Search by title or genre ─────────────────────────────────
        public List<Movie> search(String keyword) {
            String sql = """
                SELECT * FROM movies
                WHERE is_active = TRUE
                  AND (title LIKE ? OR genre LIKE ? OR language LIKE ?)
                ORDER BY title
                """;
            String like = "%" + keyword + "%";
            return jdbcTemplate.query(sql, movieRowMapper, like, like, like);
        }

        // ── Insert ───────────────────────────────────────────────────
        public void save(Movie movie) {
            String sql = """
                INSERT INTO movies
                (title, genre, duration, release_date, language,
                 rating, poster_url, description, is_active, created_by)
                VALUES (?, ?, ?, ?, ?, ?, ?, ?, TRUE, ?)
                """;
            jdbcTemplate.update(sql,
                    movie.getTitle(), movie.getGenre(), movie.getDuration(),
                    movie.getReleaseDate(), movie.getLanguage(),
                    movie.getRating(), movie.getPosterUrl(),
                    movie.getDescription(), movie.getCreatedBy());
        }

        // ── Update ───────────────────────────────────────────────────
        public int update(Movie movie) {
            String sql = """
                UPDATE movies SET
                    title        = ?,
                    genre        = ?,
                    duration     = ?,
                    release_date = ?,
                    language     = ?,
                    rating       = ?,
                    poster_url   = ?,
                    description  = ?
                WHERE movie_id = ? AND created_by = ?
                """;
            return jdbcTemplate.update(sql,
                    movie.getTitle(), movie.getGenre(), movie.getDuration(),
                    movie.getReleaseDate(), movie.getLanguage(),
                    movie.getRating(), movie.getPosterUrl(),
                    movie.getDescription(),
                    movie.getMovieId(), movie.getCreatedBy());
        }

        // ── Soft delete ──────────────────────────────────────────────
        public int softDelete(Long movieId, Long managerId) {
            String sql = "UPDATE movies SET is_active = FALSE WHERE movie_id = ? AND created_by = ?";
            return jdbcTemplate.update(sql, movieId, managerId);
        }
    }
