package com.example.movie_booking.Model;



import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import java.math.BigDecimal;
import java.time.LocalDate;
import java.time.LocalTime;

@Data
@NoArgsConstructor
@AllArgsConstructor
public class Show {
    private Long       showId;
    private Long       movieId;
    private Long       screenId;
    private LocalDate  showDate;
    private LocalTime  showTime;
    private BigDecimal priceSilver;
    private BigDecimal priceGold;
    private BigDecimal pricePlatinum;
    private boolean    isActive;
}
