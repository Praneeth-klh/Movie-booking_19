package com.example.movie_booking.Model;

public class Booking {
}
