package com.example.movie_booking.Service;
import org.springframework.stereotype.Service;
import java.util.UUID;

@Service
public class PaymentService {

    // Simulates a payment gateway — always succeeds in demo
    // Replace with Razorpay / Stripe SDK in production
    public PaymentResult process(String paymentMode, double amount) {
        // Simulate 95% success rate
        boolean success = Math.random() > 0.05;
        String ref = success ? "PAY-" + UUID.randomUUID().toString().substring(0, 8).toUpperCase() : null;
        return new PaymentResult(success, ref);
    }

    public record PaymentResult(boolean success, String paymentRef) {}
}
