package com.example.movie_booking.dto;



import jakarta.validation.constraints.*;
import lombok.Data;
import java.util.List;

@Data
public class BookingRequest {

    @NotNull(message = "Show ID is required")
    private Long showId;

    @NotEmpty(message = "Select at least one seat")
    private List<Long> seatIds;

    @NotBlank(message = "Payment mode is required")
    private String paymentMode;   // CARD / UPI / WALLET / NETBANKING
}
