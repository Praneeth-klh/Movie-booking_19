package com.example.movie_booking.security;
import io.jsonwebtoken.Claims;
import org.springframework.security.core.context.SecurityContextHolder;
public class SecurityUtil {

    // Call this inside any controller to get logged-in user's ID
    public class SecurityUtils {

        private SecurityUtils() {}

        public static String getCurrentEmail() {
            return (String) SecurityContextHolder
                    .getContext()
                    .getAuthentication()
                    .getPrincipal();
        }
    }
}
