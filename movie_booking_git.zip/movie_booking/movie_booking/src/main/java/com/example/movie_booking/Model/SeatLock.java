package com.example.movie_booking.Model;



import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import java.time.LocalDateTime;

@Data
@NoArgsConstructor
@AllArgsConstructor
public class SeatLock {
    private Long          lockId;
    private Long          seatId;
    private Long          showId;
    private Long          userId;
    private LocalDateTime lockedAt;
    private LocalDateTime expiresAt;
}