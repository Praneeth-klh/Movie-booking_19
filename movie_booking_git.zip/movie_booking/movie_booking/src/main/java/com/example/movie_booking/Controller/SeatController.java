package com.example.movie_booking.Controller;
import com.example.movie_booking.dto.SeatLockRequest;
import com.example.movie_booking.dto.SeatResponse;
import com.example.movie_booking.Service.SeatService;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.validation.Valid;
import lombok.RequiredArgsConstructor;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.Map;

@RestController
@RequestMapping("/api/seats")
@RequiredArgsConstructor
public class SeatController {

    private final SeatService seatService;

    @GetMapping("/show/{showId}")
    public ResponseEntity<List<SeatResponse>> getSeatsForShow(@PathVariable Long showId) {
        return ResponseEntity.ok(seatService.getSeatsForShow(showId));
    }

    @PostMapping("/lock")
    public ResponseEntity<Map<String, String>> lockSeats(
            @Valid @RequestBody SeatLockRequest request,
            HttpServletRequest req) {
        Long userId = (Long) req.getAttribute("userId");
        seatService.lockSeats(request, userId);
        return ResponseEntity.ok(Map.of(
                "message", "Seats locked for 5 minutes. Please complete payment."));
    }

    @PostMapping("/release")
    public ResponseEntity<Map<String, String>> releaseSeats(
            @Valid @RequestBody SeatLockRequest request,
            HttpServletRequest req) {
        Long userId = (Long) req.getAttribute("userId");
        seatService.releaseLocks(request, userId);
        return ResponseEntity.ok(Map.of("message", "Seat locks released"));
    }
}}
