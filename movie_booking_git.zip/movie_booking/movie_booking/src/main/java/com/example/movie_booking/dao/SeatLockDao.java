package com.example.movie_booking.dao;
import com.example.movie_booking.Model.SeatLock;
import lombok.RequiredArgsConstructor;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.RowMapper;
import org.springframework.stereotype.Repository;

import java.time.LocalDateTime;
import java.util.List;

@Repository
@RequiredArgsConstructor
public class SeatLockDao {

    private final JdbcTemplate jdbcTemplate;

    private final RowMapper<SeatLock> lockRowMapper = (rs, rowNum) -> new SeatLock(
            rs.getLong("lock_id"),
            rs.getLong("seat_id"),
            rs.getLong("show_id"),
            rs.getLong("user_id"),
            rs.getTimestamp("locked_at").toLocalDateTime(),
            rs.getTimestamp("expires_at").toLocalDateTime()
    );

    // Active (non-expired) locked seat IDs for a show
    public List<Long> findActiveLockedSeatIds(Long showId) {
        String sql = """
                SELECT seat_id FROM seat_locks
                WHERE show_id = ? AND expires_at > NOW()
                """;
        return jdbcTemplate.queryForList(sql, Long.class, showId);
    }

    // Check if any of the requested seats are already locked by others
    public List<Long> findConflictingLocks(Long showId, List<Long> seatIds, Long userId) {
        String placeholders = String.join(",", seatIds.stream().map(id -> "?").toList());
        String sql = String.format("""
                SELECT seat_id FROM seat_locks
                WHERE show_id = ? AND seat_id IN (%s)
                  AND user_id != ? AND expires_at > NOW()
                """, placeholders);

        Object[] params = new Object[seatIds.size() + 2];
        params[0] = showId;
        for (int i = 0; i < seatIds.size(); i++) params[i + 1] = seatIds.get(i);
        params[params.length - 1] = userId;

        return jdbcTemplate.queryForList(sql, Long.class, params);
    }

    // Lock seats — upsert per seat
    public void lockSeats(Long showId, List<Long> seatIds, Long userId, LocalDateTime expiresAt) {
        String sql = """
                INSERT INTO seat_locks (seat_id, show_id, user_id, expires_at)
                VALUES (?, ?, ?, ?)
                ON DUPLICATE KEY UPDATE
                    user_id    = VALUES(user_id),
                    locked_at  = NOW(),
                    expires_at = VALUES(expires_at)
                """;
        jdbcTemplate.batchUpdate(sql, seatIds, seatIds.size(), (ps, seatId) -> {
            ps.setLong(1,      seatId);
            ps.setLong(2,      showId);
            ps.setLong(3,      userId);
            ps.setObject(4,    expiresAt);
        });
    }

    // Release locks held by a user for a show
    public void releaseLocks(Long showId, List<Long> seatIds, Long userId) {
        String placeholders = String.join(",", seatIds.stream().map(id -> "?").toList());
        String sql = String.format(
                "DELETE FROM seat_locks WHERE show_id = ? AND seat_id IN (%s) AND user_id = ?",
                placeholders);

        Object[] params = new Object[seatIds.size() + 2];
        params[0] = showId;
        for (int i = 0; i < seatIds.size(); i++) params[i + 1] = seatIds.get(i);
        params[params.length - 1] = userId;

        jdbcTemplate.update(sql, params);
    }

    // Cleanup expired locks (called by scheduler)
    public int purgeExpiredLocks() {
        return jdbcTemplate.update("DELETE FROM seat_locks WHERE expires_at <= NOW()");
    }
}
