package com.example.movie_booking.dto;

import lombok.AllArgsConstructor;
import lombok.Data;
import java.math.BigDecimal;
import java.time.LocalDate;
import java.time.LocalTime;

@Data
@AllArgsConstructor
public class ShowResponse {
    private Long       showId;
    private Long       movieId;
    private String     movieTitle;
    private Long       screenId;
    private String     screenName;
    private String     theaterName;
    private String     city;
    private LocalDate  showDate;
    private LocalTime  showTime;
    private BigDecimal priceSilver;
    private BigDecimal priceGold;
    private BigDecimal pricePlatinum;
    private int        availableSeats;
}
