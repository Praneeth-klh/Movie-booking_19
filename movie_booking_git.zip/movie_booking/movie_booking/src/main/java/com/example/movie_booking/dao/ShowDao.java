package com.example.movie_booking.dao;

import com.example.movie_booking.Model.Show;
import lombok.RequiredArgsConstructor;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.RowMapper;
import org.springframework.jdbc.support.GeneratedKeyHolder;
import org.springframework.jdbc.support.KeyHolder;
import org.springframework.stereotype.Repository;

import java.sql.PreparedStatement;
import java.sql.Statement;
import java.time.LocalDate;
import java.util.List;
import java.util.Optional;

@Repository
@RequiredArgsConstructor
public class ShowDao {

    private final JdbcTemplate jdbcTemplate;

    private final RowMapper<Show> showRowMapper = (rs, rowNum) -> new Show(
            rs.getLong("show_id"),
            rs.getLong("movie_id"),
            rs.getLong("screen_id"),
            rs.getDate("show_date").toLocalDate(),
            rs.getTime("show_time").toLocalTime(),
            rs.getBigDecimal("price_silver"),
            rs.getBigDecimal("price_gold"),
            rs.getBigDecimal("price_platinum"),
            rs.getBoolean("is_active")
    );

    public List<Show> findByMovieAndDate(Long movieId, LocalDate date) {
        String sql = "SELECT * FROM shows WHERE movie_id = ? AND show_date = ? AND is_active = TRUE";
        return jdbcTemplate.query(sql, showRowMapper, movieId, date);
    }

    public List<Show> findByScreen(Long screenId) {
        String sql = "SELECT * FROM shows WHERE screen_id = ? AND is_active = TRUE";
        return jdbcTemplate.query(sql, showRowMapper, screenId);
    }

    public Optional<Show> findById(Long showId) {
        String sql = "SELECT * FROM shows WHERE show_id = ?";
        return jdbcTemplate.query(sql, showRowMapper, showId)
                .stream().findFirst();
    }

    public boolean hasConflict(Long screenId, LocalDate date, java.time.LocalTime time, Long excludeShowId) {
        String sql = """
                SELECT COUNT(*) FROM shows
                WHERE screen_id = ? AND show_date = ? AND show_time = ?
                  AND is_active = TRUE AND show_id != ?
                """;
        Integer count = jdbcTemplate.queryForObject(sql, Integer.class,
                screenId, date, time, excludeShowId == null ? -1 : excludeShowId);
        return count != null && count > 0;
    }

    public Long save(Show show) {
        String sql = """
                INSERT INTO shows
                (movie_id, screen_id, show_date, show_time,
                 price_silver, price_gold, price_platinum, is_active)
                VALUES (?, ?, ?, ?, ?, ?, ?, TRUE)
                """;
        KeyHolder kh = new GeneratedKeyHolder();
        jdbcTemplate.update(conn -> {
            PreparedStatement ps = conn.prepareStatement(sql, Statement.RETURN_GENERATED_KEYS);
            ps.setLong(1,   show.getMovieId());
            ps.setLong(2,   show.getScreenId());
            ps.setObject(3, show.getShowDate());
            ps.setObject(4, show.getShowTime());
            ps.setBigDecimal(5, show.getPriceSilver());
            ps.setBigDecimal(6, show.getPriceGold());
            ps.setBigDecimal(7, show.getPricePlatinum());
            return ps;
        }, kh);
        return kh.getKey().longValue();
    }

    public int softDelete(Long showId) {
        return jdbcTemplate.update(
                "UPDATE shows SET is_active = FALSE WHERE show_id = ?", showId);
    }

    // Count booked seats for a show (used for availability)
    public int countBookedSeats(Long showId) {
        String sql = """
                SELECT COUNT(*) FROM booking_seats bs
                JOIN bookings b ON bs.booking_id = b.booking_id
                WHERE b.show_id = ? AND b.status != 'CANCELLED'
                """;
        Integer count = jdbcTemplate.queryForObject(sql, Integer.class, showId);
        return count == null ? 0 : count;
    }
}