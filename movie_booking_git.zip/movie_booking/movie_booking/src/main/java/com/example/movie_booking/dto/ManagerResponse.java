package com.example.movie_booking.dto;



import lombok.AllArgsConstructor;
import lombok.Data;

@Data
@AllArgsConstructor
public class ManagerResponse {
    private Long   userId;
    private String name;
    private String email;
    private String createdAt;
}
