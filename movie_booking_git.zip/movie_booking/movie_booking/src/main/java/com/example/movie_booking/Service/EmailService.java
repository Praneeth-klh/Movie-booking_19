package com.example.movie_booking.Service;
import com.example.movie_booking.dao.UserDao;
import com.example.movie_booking.dto.BookingResponse;
import com.example.movie_booking.Model.User;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.mail.SimpleMailMessage;
import org.springframework.mail.javamail.JavaMailSender;
import org.springframework.scheduling.annotation.Async;
import org.springframework.stereotype.Service;

@Slf4j
@Service
@RequiredArgsConstructor
public class EmailService {

    private final JavaMailSender mailSender;
    private final UserDao        userDao;

    @Async
    public void sendBookingConfirmation(Long userId, BookingResponse booking) {
        try {
            User user = userDao.findById(userId).orElse(null);
            if (user == null) return;

            String body = """
                    🎬 Booking Confirmed!
                    
                    Hi %s,
                    
                    Your booking is confirmed. Here are your details:
                    
                    Movie     : %s
                    Theater   : %s  |  Screen: %s
                    Date      : %s  |  Time  : %s
                    Seats     : %s
                    Amount    : ₹%.2f (incl. ₹%.2f convenience fee)
                    Payment   : %s  |  Ref: %s
                    Booking ID: %s
                    
                    Enjoy the show! 🍿
                    """.formatted(
                    user.getName(),
                    booking.getMovieTitle(),
                    booking.getTheaterName(), booking.getScreenName(),
                    booking.getShowDate(), booking.getShowTime(),
                    String.join(", ", booking.getSeatNumbers()),
                    booking.getTotalAmount(), booking.getDeliveryCharge(),
                    booking.getPaymentMode(), booking.getPaymentRef(),
                    booking.getBookingId()
            );

            SimpleMailMessage message = new SimpleMailMessage();
            message.setTo(user.getEmail());
            message.setSubject("Booking Confirmed — " + booking.getMovieTitle());
            message.setText(body);
            mailSender.send(message);

        } catch (Exception e) {
            log.error("Failed to send confirmation email for booking {}: {}",
                    booking.getBookingId(), e.getMessage());
        }
    }
}
