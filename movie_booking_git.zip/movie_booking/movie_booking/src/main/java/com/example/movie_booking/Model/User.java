package com.example.movie_booking.Model;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.AllArgsConstructor;

@Data
@NoArgsConstructor
@AllArgsConstructor
public class User {
        private Long userId;
        private String name;
        private String email;
        private String password;
        private String role;
}
