package com.example.movie_booking.Controller;



import com.example.movie_booking.dto.BookingRequest;
import com.example.movie_booking.dto.BookingResponse;
import com.example.movie_booking.Service.BookingService;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.validation.Valid;
import lombok.RequiredArgsConstructor;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.Map;

@RestController
@RequestMapping("/api/bookings")
@RequiredArgsConstructor
public class BookingController {

    private BookingService bookingService;

    @PostMapping
    public ResponseEntity<BookingResponse> createBooking(
            @Valid @RequestBody BookingRequest request,
            HttpServletRequest req) {
        Long userId = (Long) req.getAttribute("userId");
        return ResponseEntity.ok(bookingService.createBooking(request, userId));
    }

    @GetMapping
    public ResponseEntity<List<BookingResponse>> getMyBookings(HttpServletRequest req) {
        Long userId = (Long) req.getAttribute("userId");
        return ResponseEntity.ok(bookingService.getMyBookings(userId));
    }

    @GetMapping("/{bookingId}")
    public ResponseEntity<BookingResponse> getBookingById(
            @PathVariable Long bookingId,
            HttpServletRequest req) {
        Long userId = (Long) req.getAttribute("userId");
        return ResponseEntity.ok(bookingService.getBookingById(bookingId, userId));
    }

    @PatchMapping("/{bookingId}/cancel")
    public ResponseEntity<Map<String, String>> cancelBooking(
            @PathVariable Long bookingId,
            HttpServletRequest req) {
        Long userId = (Long) req.getAttribute("userId");
        bookingService.cancelBooking(bookingId, userId);
        return ResponseEntity.ok(Map.of("message", "Booking cancelled successfully"));
    }
}
