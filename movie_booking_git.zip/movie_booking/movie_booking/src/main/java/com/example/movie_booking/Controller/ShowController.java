package com.example.movie_booking.Controller;



import com.example.movie_booking.dto.ShowRequest;
import com.example.movie_booking.dto.ShowResponse;
import com.example.movie_booking.Service.ShowService;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.validation.Valid;
import lombok.RequiredArgsConstructor;
import org.springframework.format.annotation.DateTimeFormat;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.*;

import java.time.LocalDate;
import java.util.List;
import java.util.Map;

@RestController
@RequestMapping("/api/shows")
@RequiredArgsConstructor
public class ShowController {

    private final ShowService showService;

    @GetMapping
    public ResponseEntity<List<ShowResponse>> getShows(
            @RequestParam Long movieId,
            @RequestParam @DateTimeFormat(iso = DateTimeFormat.ISO.DATE) LocalDate date) {
        return ResponseEntity.ok(showService.getShowsByMovieAndDate(movieId, date));
    }

    @GetMapping("/{showId}")
    public ResponseEntity<ShowResponse> getShowById(@PathVariable Long showId) {
        return ResponseEntity.ok(showService.getShowById(showId));
    }

    @PreAuthorize("hasRole('MANAGER')")
    @PostMapping
    public ResponseEntity<Map<String, Object>> addShow(
            @Valid @RequestBody ShowRequest request,
            HttpServletRequest req) {
        Long managerId = (Long) req.getAttribute("userId");
        Long showId = showService.addShow(request, managerId);
        return ResponseEntity.ok(Map.of("message", "Show added successfully", "showId", showId));
    }

    @PreAuthorize("hasRole('MANAGER')")
    @DeleteMapping("/{showId}")
    public ResponseEntity<Map<String, String>> cancelShow(
            @PathVariable Long showId,
            HttpServletRequest req) {
        Long managerId = (Long) req.getAttribute("userId");
        showService.cancelShow(showId, managerId);
        return ResponseEntity.ok(Map.of("message", "Show cancelled successfully"));
    }
}
