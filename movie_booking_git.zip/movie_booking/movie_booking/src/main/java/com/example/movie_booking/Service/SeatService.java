package com.example.movie_booking.Service;
import com.example.movie_booking.dao.*;
import com.example.movie_booking.dto.SeatLockRequest;
import com.example.movie_booking.dto.SeatResponse;
import com.example.movie_booking.Exception.AppException;
import com.example.movie_booking.Model.*;
import lombok.RequiredArgsConstructor;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Service;

import java.time.LocalDateTime;
import java.util.*;
import java.util.stream.Collectors;

@Service
@RequiredArgsConstructor
public class SeatService {

    private static final int LOCK_MINUTES = 5;

    private final SeatDao     seatDao;
    private final SeatLockDao seatLockDao;
    private final ShowDao     showDao;
    private final ScreenDao   screenDao;

    // ── Get all seats for a show with live status ─────────────────
    public List<SeatResponse> getSeatsForShow(Long showId) {
        Show show = showDao.findById(showId)
                .orElseThrow(() -> new AppException("Show not found", HttpStatus.NOT_FOUND));

        List<Seat> allSeats = seatDao.findByScreen(show.getScreenId());

        // 50% online rule — only half the seats are sellable online
        Screen screen = screenDao.findById(show.getScreenId()).orElseThrow();
        int onlineLimit = screen.getSeatingCapacity() / 2;
        List<Seat> onlineSeats = allSeats.subList(0, Math.min(onlineLimit, allSeats.size()));

        Set<Long> bookedIds = new HashSet<>(seatDao.findBookedSeatIds(showId));
        Set<Long> lockedIds = new HashSet<>(seatLockDao.findActiveLockedSeatIds(showId));

        return onlineSeats.stream().map(seat -> {
            String status;
            if (bookedIds.contains(seat.getSeatId()))      status = "BOOKED";
            else if (lockedIds.contains(seat.getSeatId())) status = "LOCKED";
            else                                           status = "AVAILABLE";

            return new SeatResponse(
                    seat.getSeatId(), seat.getSeatNumber(),
                    seat.getSeatClass(), status);
        }).toList();
    }

    // ── Lock seats for 5 minutes ──────────────────────────────────
    public void lockSeats(SeatLockRequest request, Long userId) {
        Show show = showDao.findById(request.getShowId())
                .orElseThrow(() -> new AppException("Show not found", HttpStatus.NOT_FOUND));

        // Check for already-booked seats
        Set<Long> bookedIds = new HashSet<>(seatDao.findBookedSeatIds(request.getShowId()));
        List<Long> alreadyBooked = request.getSeatIds().stream()
                .filter(bookedIds::contains).toList();
        if (!alreadyBooked.isEmpty()) {
            throw new AppException("Seats already booked: " + alreadyBooked, HttpStatus.CONFLICT);
        }

        // Check for locks held by other users
        List<Long> conflicting = seatLockDao.findConflictingLocks(
                request.getShowId(), request.getSeatIds(), userId);
        if (!conflicting.isEmpty()) {
            throw new AppException(
                    "Seats currently held by another user: " + conflicting,
                    HttpStatus.CONFLICT);
        }

        LocalDateTime expiresAt = LocalDateTime.now().plusMinutes(LOCK_MINUTES);
        seatLockDao.lockSeats(request.getShowId(), request.getSeatIds(), userId, expiresAt);
    }

    // ── Release locks ─────────────────────────────────────────────
    public void releaseLocks(SeatLockRequest request, Long userId) {
        seatLockDao.releaseLocks(request.getShowId(), request.getSeatIds(), userId);
    }

    // ── Auto-generate seats for a new screen ─────────────────────
    // Layout: rows A-J, seats 1-N per row
    // First 40% → SILVER, next 40% → GOLD, last 20% → PLATINUM
    public void generateSeatsForScreen(Long screenId, int capacity) {
        List<Seat> seats = new ArrayList<>();
        int silverLimit   = (int) (capacity * 0.40);
        int goldLimit     = (int) (capacity * 0.80);
        int seatsPerRow   = 10;
        int totalRows     = (int) Math.ceil((double) capacity / seatsPerRow);
        int count         = 0;

        outer:
        for (int row = 0; row < totalRows; row++) {
            char rowLabel = (char) ('A' + row);
            for (int col = 1; col <= seatsPerRow; col++) {
                if (count >= capacity) break outer;
                String seatClass = count < silverLimit   ? "SILVER"
                        : count < goldLimit     ? "GOLD"
                        :                         "PLATINUM";
                seats.add(new Seat(null, screenId, rowLabel + String.valueOf(col), seatClass, true));
                count++;
            }
        }
        seatDao.bulkInsert(screenId, seats);
    }
}
